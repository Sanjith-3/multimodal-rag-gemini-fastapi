from fastapi import UploadFile, File, HTTPException , FastAPI
import os
import shutil
from pydantic import BaseModel
import logging

def get_rag_chain(query):
    return query

# class ModelName(str):
#     GPT4_O = "gpt-4o"
#     GPT4_O_MINI = "gpt-4o-mini"

class QueryInput(BaseModel):
    question: str

class QueryResponse(BaseModel):
    answer: str

class DocumentInfo(BaseModel):
    filename: str

class ResponseEval(BaseModel):
    answer: str
    reference_context: str
    reference_response: str

class Eval(BaseModel):
    answer: str
    metrix_1: float
    metrix_2: float
    metrix_3: float
    metrix_4: float
    metrix_5: float

app = FastAPI()

@app.post("/upload-doc")
def upload_and_return_document(file: UploadFile = File(...)):
    allowed_extensions = ['.pdf', '.docx', '.html']
    file_extension = file.filename.split('.')[-1].lower()

    # Validate file type
    if f".{file_extension}" not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type. Allowed types are: {', '.join(allowed_extensions)}"
        )

    # Return file information
    return {
        "filename": file.filename,
        "content_type": file.content_type,
        "message": "File uploaded successfully!"
    }
    
# @app.post("/chat", response_model=QueryResponse)
# def chat(query_input: QueryInput):
#     logging.info("User Query: {query_input.question}")
#     if query_input.question is None:
#         logging.error("Query shpuld not be None")


#     answer = get_rag_chain(query_input.question)
    
    
#     logging.info(f" Query: {query_input.question}, AI Response: {answer}")
#     return QueryResponse(answer=answer)


@app.post("/evaluate", response_model=ResponseEval)
def chat(response_input: ResponseEval):
    logging.info("query response: {response_input.answer}","reference context: {response_input.reference_context}","refernce response: {response_input.reference_response}")
    if response_input.answer is None:
        logging.error("response is not generated")
    return ResponseEval(answer=response_input.answer,reference_context=response_input.reference_context,reference_response=response_input.reference_response)


@app.post("/evaluate-metrics",response_model=Eval)
def chat(response_eval: ResponseEval):
    if response_eval is None:
        logging.error("response_eval not generated")
    return Eval(answer=response_eval.answer,metrix_1=0.0,metrix_2=0.0,metrix_3=0.0,metrix_4=0.0,metrix_5=0.0)